# 1. Docker
sudo apt update
sudo apt install -y docker.io
sudo usermod -aG docker $USER      # log out/in after this

# 2. kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# 3. kind (Kubernetes In Docker)
curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.22.0/kind-linux-amd64
chmod +x ./kind && sudo mv ./kind /usr/local/bin/

# 4. (optional) helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

