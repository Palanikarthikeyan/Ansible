# create namespace
kubectl create namespace awx

# deploy the operator using kustomize (from the awx-operator repo)
kubectl apply -k "github.com/ansible/awx-operator/config/default?ref=main" -n awx

# verify operator is running
kubectl get pods -n awx

